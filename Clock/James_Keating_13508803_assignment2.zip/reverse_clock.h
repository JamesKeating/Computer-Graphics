#ifndef REVERSE_CLOCK_H
#define REVERSE_CLOCK_H
#include "clock.h"

class Reverse_Clock: public Clock
{
public:
    void tick();
};

#endif // REVERSE_CLOCK_H
