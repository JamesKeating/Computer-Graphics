#ifndef NORMAL_CLOCK_H
#define NORMAL_CLOCK_H
#include "clock.h"

class Normal_Clock: public Clock
{
public:
    void tick();
};

#endif // NORMAL_CLOCK_H
