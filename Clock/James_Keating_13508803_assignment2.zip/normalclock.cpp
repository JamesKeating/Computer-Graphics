#include "normal_clock.h"

NormalClock::normal_clock()
{

}
